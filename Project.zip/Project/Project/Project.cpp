#include<iostream>
#include<string>
#include <fstream>
#include <sstream>
#include<algorithm>
#include <vector>
#include <math.h>


using namespace std;


const int MaximumStore=100; //maximum number of Stores
const int MaximumItem=100; // total maximum number of Item 
const int MaximumShopingList=100; 
int FindedTempIndexItem; // For check Item in list that inserted befor
int IndextItemList=-1; // Save current Item in List


struct Item
{
	Item() // Constructor
	{
		CurrentIndex=-1;
		TotalQuantity=0;
	}

	// Function for new Item
	void Add(string NoI,int Store_ID,int Cost,int Quantity) 
	{
		CurrentIndex++;	
		ItemName=NoI;
		Costs[CurrentIndex]=Cost;
		Quantities[CurrentIndex]=Quantity;
		StoreIDs[CurrentIndex]=Store_ID;
		TotalQuantity+=Quantities[CurrentIndex];

		sortArr(Costs, CurrentIndex+1); 
	}

	// Function for add 
	void Add(int Store_ID,int Cost,int Quantity) 
	{
		CurrentIndex++;	
		Costs[CurrentIndex]=Cost;
		Quantities[CurrentIndex]=Quantity;
		StoreIDs[CurrentIndex]=Store_ID;
		TotalQuantity+=Quantities[CurrentIndex];

		sortArr(Costs, CurrentIndex+1); 


	}


	// Function for sorting Store ID for best purchase 
	void sortArr(int arr[], int n) 
	{ 

		// Vector to store element 
		// with respective present index 
		vector<pair<int, int> > vp; 

		// Inserting element in pair vector 
		// to keep track of previous indexes 
		for (int i = 0; i < n; ++i) { 
			vp.push_back(make_pair(arr[i], i)); 
		} 

		// Sorting pair vector 
		sort(vp.begin(), vp.end()); 

		// "Element\t" ......"index" << endl; 
		for (int i = 0; i < vp.size(); i++) { 
			//vp[i].first << "\t"
			BestPurchaseOrder[i]= vp[i].second;
		} 
	} 


	string ItemName;    // Item Name
	int TotalQuantity; // Total quantity of this Item
	int CurrentIndex; // this parametres use for handeling save information

	int StoreIDs[MaximumStore];
	int Costs[MaximumStore];
	int Quantities[MaximumStore];

	int BestPurchaseOrder[MaximumStore];
};



struct Store
{
	Store()
	{
		ItemNumber=0;
	}
	int StoreID;
	string StoreName;
	string StoreLocation;
	int ItemNumber; // number of Item in this Store
}; 


bool in_array(string value, string *array)
{
	if (IndextItemList>-1)
	{
		for (int i = 0; i <= IndextItemList; i++)
		{
			if (value == array[i])
			{
				FindedTempIndexItem=i;
				return true;
			}
		}
	}

	return false;
}


void main()
{
	ifstream file("Input.txt");
	char Delim=',';
	string NameOfItem;
	string TempS;
	int QuentityOfItem;
	int CostOfItem;

	string ItemListName[MaximumItem];
	Item Items[MaximumItem]; // Item arrays
	int LastItemIndex=-1;

	string tempLine;
	getline(file, tempLine); 

	int StoreNumer=0;
	StoreNumer=stoi(tempLine); // fetch number of stores from line one

	Store ST[MaximumStore];



	for(int i=0;i<StoreNumer;i++)
	{

		////////////////////////////////////////////////////////// Save Info of store i
		getline(file, tempLine); // Store Name Fetched 
		ST[i].StoreID=i;
		ST[i].StoreName=tempLine;
		getline(file, tempLine); //Store Location fetched
		ST[i].StoreLocation=tempLine;



		//////////////////////////////////////////////////////////////////// fetch Items of Stores i
		int TempNumberofItem=0;

		getline(file, tempLine);
		while(tempLine!="")
		{
			TempNumberofItem++;
			stringstream ss(tempLine);


			getline(ss, NameOfItem, Delim); // fetch Item Name
			getline(ss, TempS, Delim);// Fetch Item Quantity
			QuentityOfItem=stoi(TempS);
			getline(ss, TempS, Delim);// Fetch Cost
			TempS.erase(remove(TempS.begin(), TempS.end(), '$'), TempS.end()); //remove $ from Cost
			TempS.erase(remove(TempS.begin(), TempS.end(), '.'), TempS.end()); //remove . from Cost
			CostOfItem=stoi(TempS);


			if (in_array(NameOfItem, ItemListName))
			{
				Items[FindedTempIndexItem].Add(ST[i].StoreID,CostOfItem,QuentityOfItem); // Add Info of Item that exsit in new Store
			}
			else
			{ 
				ItemListName[++IndextItemList]=NameOfItem; // Add new Item Names in Item Name List
				Items[++LastItemIndex].Add(NameOfItem,ST[i].StoreID,CostOfItem,QuentityOfItem); // Create New Item and add Info of it
			}


			getline(file, tempLine);
		}
		ST[i].ItemNumber=TempNumberofItem;


	}


	/////////////////////////////////////// Store Informations 
	cout<<"Store Related Information (ordered by in-file order):"<<endl;
	cout<<"There are "<<StoreNumer <<" store(s)."<<endl;
	for(int i=0;i<StoreNumer;i++)
	{
		cout<<ST[i].StoreName <<"has "<<ST[i].ItemNumber<<" distinct items."<<endl;
	}


	////////////////////////////////////// Items Informations
	cout<<endl<<"Item Related Information (ordered alphabetically):"<<endl;
	cout<<"There are "+to_string(IndextItemList+1)+" distinct item(s) available for purchase."<<endl;
	int N = sizeof(ItemListName)/sizeof(ItemListName[0]); //Get the array size
	string ItemListName2[sizeof(ItemListName)];
	copy(begin(ItemListName), end(ItemListName), begin(ItemListName2));
	sort(ItemListName2,ItemListName2+IndextItemList+1); // Sorting Part

	for(int i = 0; i < N; i++)
	{
		if(ItemListName2[i]!="")
		{
			in_array(ItemListName2[i], ItemListName);
			cout <<"There are "<<Items[FindedTempIndexItem].TotalQuantity <<" "<<ItemListName2[i] <<"(s)"<< endl;
		}
		else
			break;
	}


	///////////////////////////////////////////////// Get Shopping List

	getline(file, tempLine);
	int NumberOfShopping=stoi(tempLine); // 
	int ShopingList_Q[MaximumShopingList];
	string ShopingList_Name[MaximumShopingList];

	//string TempShopL;
	for(int j=0;j<NumberOfShopping;j++)
	{
		getline(file, tempLine);
		stringstream ss(tempLine);
		getline(ss, TempS, ' ');
		ShopingList_Q[j]=stoi(TempS);
		getline(ss, ShopingList_Name[j]);
	}

	//////////////////////////////////////////////// Find Solution of Shopping List

	cout<<endl<<"Shopping:"<<endl;
	int TotalPrice;
	int TotalStores;
	int Total_TotalPrice=0;
	for(int j=0;j<NumberOfShopping;j++)
	{
		cout<<"Trying to order "<<ShopingList_Q[j]<<" "<<ShopingList_Name[j]<<"(s)"<<endl;
		string Temp_Shop="";
		TotalPrice=0;
		TotalStores=0;
		in_array(ShopingList_Name[j], ItemListName);
		if(Items[FindedTempIndexItem].TotalQuantity < ShopingList_Q[j]) // when you enter wrong input
		{
			for(int k=0;k<=Items[FindedTempIndexItem].CurrentIndex;k++)
			{
				
				int BOP_Index=Items[FindedTempIndexItem].BestPurchaseOrder[k]; // Best List Index inside of Item Structure
				int BOP_ID=Items[FindedTempIndexItem].StoreIDs[Items[FindedTempIndexItem].BestPurchaseOrder[k]]; // ID of Best Store for Order 
				int BPO_Q=Items[FindedTempIndexItem].Quantities[BOP_Index];
				TotalStores++;
				Temp_Shop+= "Order "+  to_string(BPO_Q) + " from "+ST[BOP_ID].StoreName +" in "+ST[BOP_ID].StoreLocation+" \n";
				TotalPrice=TotalPrice+BPO_Q*Items[FindedTempIndexItem].Costs[BOP_Index];
				ShopingList_Q[j]=ShopingList_Q[j]-BPO_Q;
			}
		}
		else
		{
			for(int k=0;k<=Items[FindedTempIndexItem].CurrentIndex;k++)
			{
				
				int BOP_Index=Items[FindedTempIndexItem].BestPurchaseOrder[k]; // Best List Index inside of Item Structure
				int BOP_ID=Items[FindedTempIndexItem].StoreIDs[Items[FindedTempIndexItem].BestPurchaseOrder[k]]; // ID of Best Store for Order 
				int BPO_Q=Items[FindedTempIndexItem].Quantities[BOP_Index];
				TotalStores++;
				if(BPO_Q<ShopingList_Q[j]){
					Temp_Shop+= "Order "+  to_string(BPO_Q) + " from "+ST[BOP_ID].StoreName +" in "+ST[BOP_ID].StoreLocation+" \n";
					TotalPrice=TotalPrice+BPO_Q*Items[FindedTempIndexItem].Costs[BOP_Index];
					ShopingList_Q[j]=ShopingList_Q[j]-BPO_Q;
				}
				else
				{
					Temp_Shop+= "Order "+  to_string(ShopingList_Q[j]) + " from "+ST[BOP_ID].StoreName +" in "+ST[BOP_ID].StoreLocation+" \n";
					TotalPrice=TotalPrice+ShopingList_Q[j]*Items[FindedTempIndexItem].Costs[BOP_Index];
					break;
				}

			}
		}

		cout<<to_string(TotalStores) <<" store(s) sell "<<ShopingList_Name[j]<<"(s)"<<endl;
		cout<<"Total price: $"<<to_string((float)TotalPrice/100)<<endl;
		cout<<Temp_Shop<<endl;


		Total_TotalPrice+=TotalPrice;

	}

	cout<<"Be sure to bring $"+to_string((float)Total_TotalPrice/100)+" when you leave for the stores.";
}

